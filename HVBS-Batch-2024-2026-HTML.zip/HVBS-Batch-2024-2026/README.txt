HVBS Batch 2024–2026 Website

HOW TO USE:
1. Open index.html in a browser.
2. Put your own images inside the images folder.
3. Keep these filenames if you want the image placeholders to work:
   hero.jpg
   about.jpg
   memory-1.jpg
   memory-2.jpg
   memory-3.jpg
4. Open index.html again.

You can edit the text directly inside index.html.
You can change colors, spacing and fonts inside style.css.

This is a standalone HTML/CSS recreation based on the public Google Sites page content.
